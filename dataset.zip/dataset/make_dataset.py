import json
import os
import random

# read dataset
with open('enron_spam_data.json', 'r') as f:
    emails = json.load(f)

# make directories
os.makedirs("train/spam", exist_ok=True)
os.makedirs("train/ham", exist_ok=True)
os.makedirs("test/spam", exist_ok=True)
os.makedirs("test/ham", exist_ok=True)

print('Total emails:', len(emails))
print('Spam emails:', len([email for email in emails if email["Spam/Ham"] == "spam"]))
print('Ham emails:', len([email for email in emails if email["Spam/Ham"] == "ham"]))

# divide into train and test
train_proportion = 0.8
train_size = int(len(emails) * train_proportion)

random.seed(42)
random.shuffle(emails)
train_emails = emails[:train_size]
test_emails = emails[train_size:]

# export train and test datasets
def export_dataset(emails, dir):
    print(f'Exporting {dir} dataset ({len(emails)} emails)...')
    spam_i = 1
    ham_i = 1
    for email in emails:
        if email["Spam/Ham"] == "spam":
            path = f"{dir}/spam/spam_{spam_i}.txt"
            spam_i += 1
        else:
            path = f"{dir}/ham/ham_{ham_i}.txt"
            ham_i += 1

        with open(path, 'w', encoding='utf-8') as f:
            subject = email["Subject"]
            message = email["Message"]
            f.write(f"{subject}\n\n{message}")

export_dataset(train_emails, "train")
export_dataset(test_emails, "test")